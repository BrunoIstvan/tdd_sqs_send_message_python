class InvalidSQSParametersException(Exception):
    pass